package utillities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class WebDriver_utils {
	public static WebDriver createDriver() {
		WebDriverManager.chromedriver().setup();
		return new ChromeDriver();
		
	}

}
